const mongoose = require("mongoose")

const connect = async() =>{
    const userName = "tarun";
    const password = "tarun";
    const host = "127.0.0.1";
    const PORT = "27017";
    const dbName = "unimeet";

    const connectionString = `mongodb://${ userName }:${ password }@${ host }:${ PORT }/${ dbName }`;
    console.log(`connection string is ${connectionString}`)

    try {
        const connection = await mongoose.connect(connectionString)
        console.log(`DataBase connected successfully.....`)
    } catch (error) {
        console.log(error)
    }

}

module.exports = {
    connect
}