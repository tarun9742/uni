const { Router } = require('express');
const router = Router();

const verifyToken = require('../../middlewares/jwtVerify');


// studentController path

const auth_student = require("../../controllers/studentCtrl/auth.student")

const {student_dashboard} = require("../../controllers/studentCtrl/dashboard.student");


// const {student_chat} = require("../../controllers/studentCtrl/chat.student")

// const {student_delete_account} = require("../../controllers/studentCtrl/delete.student")





// routers----------------------------------------------------------------------------------

router.post("/register", auth_student.student_register)

router.post("/login", auth_student.student_login )

router.put("/update/:id",[verifyToken], auth_student.student_update)

router.get("/dashboard",[verifyToken], student_dashboard)

// router.post("/chat", student_chat)

// router.delete("/delete-account/:id", student_delete_account)


router.post("/logout", auth_student.student_logout)



module.exports = router;