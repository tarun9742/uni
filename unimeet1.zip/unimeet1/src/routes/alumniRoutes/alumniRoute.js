const { Router } = require('express');
const router = Router();


// alumniController path
const {alumni_register} = require("../../controllers/alumniCtrl/register.alumni")

const {alumni_login} = require("../../controllers/alumniCtrl/login.alumni")

// const {alumni_update} = require("../../controllers/alumniCtrl/update.alumni")

// const {alumni_dashboard} = require("../../controllers/alumniCtrl/dashboard.alumni")

// const (alumni_profile) = require("../../controllers/alumniCtrl")

// const {alumni_chat} = require("../../controllers/alumniCtrl/chat.alumni")

// const {alumni_delete_account} = require("../../controllers/alumniCtrl/delete.alumni")

// const {alumni_logout} = require("../../controllers/alumniCtrl/logout.alumni")




// routers----------------------------------------------------------------------------------

router.post("/register", alumni_register)

router.post("/login", alumni_login)

// router.put("/update/:id", alumni_update)

// router.get("/dashboard", alumni_dashboard)

// router.get("/profile", alumni_profile)

// router.post("/chat", alumni_chat)

// router.delete("/delete-account/:id", alumni_delete_account)


// router.post("/logout", alumni_logout)



module.exports = router;