const { Router } = require('express');
const router = Router();


// admin Controller path
const { admin_login } = require('../../controllers/adminCtrl/login.admin');

// const { admin_logout } = require('../../controllers/adminCtrl/login.admin');

// const { admin_update } = require('../../controllers/adminCtrl/login.admin');

// const { all_universities } = require('../../controllers/adminCtrl/login.admin');

// const { all_alumnies } = require('../../controllers/adminCtrl/login.admin');




// admin routes

router.post("/login", admin_login)

// router.post("/logout", admin_logout)

// router.put("/update/:id", admin_update)

// router.post("/logout", admin_logout)

// router.get("/universities", all_universities)

// router.get("/alumnies", all_alumnies)




module.exports = router;