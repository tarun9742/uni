const {alumniModel} = require("../../schemas/alumniSchema")

exports.alumni_register = async(req,res,next)=>{
    const { userName ,name , password ,email ,mobile ,address ,gender , token ,isActive, university, passoutYear, country, state, universityMailId, linkedIn  } = req.body;
    const checkExistance = await alumniModel.findOne({userName: userName, email: email, mobile: mobile});
    if (checkExistance) {
        return (
            res.send("existing")
        )
    } else {
         const alumni = await alumniModel.create({
            userName,
            name,
            password,
            email,
            mobile,
            address,
            gender,
            token,
            isActive,
            university,
            passoutYear,
            country,
            state,
            universityMailId,
            linkedIn
            })
            const alumniRegisterData = await alumni.save();
            return res.send({
                success: true,
                msg: "alumni created successfully",
                info: alumniRegisterData
            })
        
    }
}