const {alumniModel} = require("../../schemas/alumniSchema")


exports.alumni_login = async(req,res,next)=>{
    const {userName, password} = req.body;
    const userData = await alumniModel.findOne({userName: userName} && {password: password})
    if (userData) {
       return(
        res.send("login")
       )

    } else {
        return(
            res.send("Either Username or password is wrong")
        )
    }
}