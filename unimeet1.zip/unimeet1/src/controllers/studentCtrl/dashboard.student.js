exports.student_dashboard = async(req,res,next)=>{
    res.send("student pannel")
}