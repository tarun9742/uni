const jwt = require("jsonwebtoken");
const secret = "##@156**34^";




const {studentModel} = require("../../schemas/studentSchema")

// Student register api-------------------------------------------------------
exports.student_register = async(req,res,next)=>{
  const { userName ,name , password ,email ,mobile ,address ,gender , token ,isActive } = req.body;
  const checkExistance = await studentModel.findOne({userName: userName, email: email, mobile: mobile});
  if (checkExistance) {
      return (
          res.send("existing")
      )
  } else {
       const student = await studentModel.create({
              userName,
              name,
              password,
              email,
              mobile,
              address,
              isActive,
              gender
          })
          const studentRegisterData = await student.save();
          return res.send({
              success: true,
              msg: "student created successfully",
              info: studentRegisterData
          })
      
  }
}


// Student login api-----------------------------------------------------------
exports.student_login = async(req,res,next)=>{
    const {userName, password} = req.body;
    const userData = await studentModel.findOne({userName: userName} && {password: password})
    if (userData) {
        const token = jwt.sign({ userName: userName },
            secret,
            {
              algorithm: 'HS256',
              allowInsecureKeySizes: true,
              expiresIn: 86400, // 24 hours
            });

        req.session.token = token;

        res.send({
          username: userData.userName,
          email: userData.email,
          msg: "logged In"
        })

    } else {
        return(
            res.send("Either Username or password is wrong")
        )
    }
}


// Student logout api---------------------------------------------------------
exports.student_logout = async (req, res) => {
    try {
      req.session = null;
      return res.status(200).send({ message: "You've been signed out!" });
    } catch (err) {
      res.send(err);
    }
};



// student profile update api----------------------------------------------------
  exports.student_update = async(req,res,next)=>{
    try {
        const userUpdatedData = req.body;
        const data = await studentModel.findByIdAndUpdate({_id: req.params.id}, userUpdatedData, {new:true})
        if (data) {
            res.send(data)
        } else {
            console.error();
        }
    } catch (error) {
        res.send(error)
    }

}