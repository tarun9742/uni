exports.student_delete_account = async(req,res,next)=>{
    res.send("student delete itself")
}