exports.student_chat = async(req,res,next)=>{
    res.send("start a chat")
}