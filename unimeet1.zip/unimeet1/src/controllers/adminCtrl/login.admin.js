
exports.admin_login = async(req,res,next)=>{
    const {userName, password} = req.body;
    if (userName === "admin" && password === "admin@123") {
        return(
            res.send("ok")
        )
    } else {
        return(
            res.send("No admin")
        )
    }
}