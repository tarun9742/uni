const jwt = require("jsonwebtoken");
const secret = "##@156**34^";

function verifyToken(req, res, next) {
  const token = req.session.token;

  if (token) {
    const decoded = jwt.verify(token, secret);
    if (decoded) {
      next();
    } else {
      res.send("Invalid token...");
    }
  } else {
    res.send({
      msg: "Please enter token ....",
    });
  }
}

module.exports = verifyToken;