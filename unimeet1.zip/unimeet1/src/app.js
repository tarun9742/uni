const express = require("express")
const app = express();
const cors = require('cors')
const bodyParser = require("body-parser")
require("dotenv").config();
const session = require('express-session');

// mongodb connection
const dbConnection = require("./config/db.config")
dbConnection.connect()


app.use(cors())
app.use(bodyParser.json())
app.use(session({
    secret: '##@156**34^', // Replace with a secret key for session handling
    resave: false,
    saveUninitialized: true,
  }));

// routes
const adminRoute = require("./routes/adminRoutes/adminRoute")
const alumniRoute = require("./routes/alumniRoutes/alumniRoute")
const studentRoute = require("./routes/studentRoutes/studentRoute")

// admin, alumni, student route
app.use("/admin", adminRoute)
app.use("/alumni", alumniRoute)
app.use("/student", studentRoute)



const PORT = process.env.PORT
app.listen(PORT, ()=>{
    console.log(`This is on port ${PORT}`)
})