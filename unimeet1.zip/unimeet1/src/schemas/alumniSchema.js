const { Schema, default: mongoose, model } = require("mongoose");

const alumni_schema = new Schema({
    userName: {type : String},
    name: {type : String},
    password: {type : String},
    email: {type : String},
    mobile: {type : Number},
    address: {type : String},
    gender: {type: String},
    token: {type: String},
    isActive: {type : Boolean},
    university: {type : String},
    passoutYear: {type: Number},
    country: {type: String},
    state: {type : String},
    UniversityMailId: {type: String},
    linkedIn: {type: String}


},{timestamps:true})

const alumniModel = mongoose.model('alumni', alumni_schema)
module.exports = {
    alumniModel
}