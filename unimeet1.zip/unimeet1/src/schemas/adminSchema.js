const { Schema, default: mongoose, model } = require("mongoose");

const admin_schema = new Schema({
    userName: {type : String},
    name: {type : String},
    password: {type : String},
    email: {type : String},
    mobile: {type : Number},
    address: {type : String},
    token: {type: String},

},{timestamps:true})

const adminModel = mongoose.model('admin', admin_schema)
module.exports = {
    adminModel
}